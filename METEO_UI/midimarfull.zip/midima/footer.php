


<div class="pull-right hidden-xs">
      <b>Powered by </b>  <a href="">Dream Team</a>
 </div>
    <strong> Copyright &copy; 2018 <a href="">METEO Rwanda & MIDIMAR  </a>.</strong> 
   