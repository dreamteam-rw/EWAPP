<section class="sidebar">
     
      <!-- search form -->
      
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
       <li> <a href="control"> <i class="fa fa-dashboard"></i> Dashboard </a></li>
      
        <li class="treeview">
          <a href="#">
            <i class="fa fa-exclamation-triangle"></i> <span>Disaster Alerts</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="new-user"> Create Alert </a></li>
            <li><a href="user-list"> Alert List</a></li>
          </ul>
        </li>
         <li class="treeview">
          <a href="#">
            <i class="fa  fa-envelope-o"></i> <span>Warning Messages </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="news"> New Warning   SMS  </a></li>
            <li><a href="news-list"> Warning  SMS List </a></li>
          </ul>
        </li>

       <li> <a href="new-spot"> <i class="fa fa-comments"></i> Forum </a></li>

         <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span> User </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="new-gal">Add User</a></li>
            <li><a href="gal-list"> User list</a></li>
          </ul>
        </li>


         

        <li> <a href="class/config.php?action_type=logout"> <i class="glyphicon glyphicon-log-out"></i> Logout </a></li>
       </ul>
    </section>