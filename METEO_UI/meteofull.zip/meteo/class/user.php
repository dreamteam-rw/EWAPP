<?php
//start session
session_start();

//load and initialize database class
require_once '../core/DB.php';
$db = new DB();

$tblName = 'user';

//set default redirect url
$redirectURL = 'index.php';

if(isset($_POST['userSubmit'])){
    if(!empty($_POST['user_fname']) && !empty($_POST['user_lname']) && !empty($_POST['user_email']) && !empty($_POST['user_password']))
    {
  
            //insert data
            $userData = array
            (
                'Firstname' => $_POST['user_fname'],
                'Lastname' => $_POST['user_lname'],
                'Email' => $_POST['user_email'],
                'Password' => md5($_POST['user_password'])

            )
            ;
            $insert = $db->insert($tblName, $userData);
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'User data has been added successfully.';
            //set redirect url
                $redirectURL = '../userlist.php';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Some problem occurred, please try again.';
                
                //set redirect url
                $redirectURL = '../register.php';
            }
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../register.php';
       }
    
    //store status into the session
    $_SESSION['sessData'] = $sessData;
    
    //redirect to the list page
    header("Location:".$redirectURL);

}

/*================================================================================================================================================================*/
// Action pour news 
if(isset($_POST['userNews'])){
    if(!empty($_POST['title_news'])  && !empty($_POST['description_news']) && !empty($_POST['detail_news']))
    {
  
        $tblName='news';


 //Process the image that is uploaded by the user

        $target_dir = "../img/";
        $target_file = $target_dir . basename($_FILES["photo_news"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    
        if (move_uploaded_file($_FILES["photo_news"]["tmp_name"], $target_file)) {
            echo "The file ". basename( $_FILES["photo_news"]["name"]). " has been uploaded.";
        } else 
        {
            echo "Sorry, there was an error uploading your file.";
        }
    
        $image=basename( $_FILES["photo_news"]["name"],".jpg"); // used to store the filename in a variable
        $pt=$image.".jpg";

//

            //insert data
            $newsData = array
            (
                'Title' => str_replace ("'","@@",$_POST['title_news']),
                'Photo' => $pt,
                'Description' => str_replace ("'","@@",$_POST['description_news']),
                'Detail' => str_replace ("'","@@",$_POST['detail_news']),
                'Date'=>  date('Y/m/d')

            )
            ;
            $insert = $db->insert($tblName, $newsData);
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Operation russie avec succes.';
            //set redirect url
                $redirectURL = '../newslist.php';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Some problem occurred, please try again.';
                
                //set redirect url
                $redirectURL = '../news.php';
            }
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../news.php';
       }
    
    //store status into the session
    $_SESSION['sessData'] = $sessData;
    
    //redirect to the list page
    header("Location:".$redirectURL);

}
exit();
?>