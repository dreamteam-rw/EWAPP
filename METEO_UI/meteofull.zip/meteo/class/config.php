<?php
//start session
session_start();

//load and initialize database class
require_once '../core/DB.php';
$db = new DB();



//set default redirect url
$redirectURL = 'index.php';

if(isset($_POST['userSubmit'])){
    if(!empty($_POST['user_fname']) && !empty($_POST['user_lname']) && !empty($_POST['user_email']) && !empty($_POST['user_password']))
    {
  
  $tblName = 'user';
            //insert data
            $userData = array
            (
                'Firstname' => $_POST['user_fname'],
                'Lastname' => $_POST['user_lname'],
                'Email' => $_POST['user_email'],
                'Password' => md5($_POST['user_password'])

            )
            ;
            $insert = $db->insert($tblName, $userData);
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie';
            //set redirect url
                $redirectURL = '../user-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard ';
                
                //set redirect url
                $redirectURL = '../new-user';
            }
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'Remplissez Tous les champs Svp';
        
        //set redirect url
        $redirectURL = '../new-user.php';
       }
   

}




 if(isset($_REQUEST["action_type"]) && $_REQUEST["action_type"]=='deleteu' )

    {
    
  
           $tblName='user';

  

// the update condintion, means where to apply the update in a table 

             $Condition = array
            (
                
                
                'ID'=> $_REQUEST['id']
            )
            ;

            $delete = $db->delete($tblName,$Condition);
            if($delete){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie avec succes.';
            //set redirect url
                $redirectURL = '../user-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard';
                
                //set redirect url
                $redirectURL = '../user-list';
            }
    }




/*====================================================================================================================================================*/
// Action pour news 
if(isset($_POST['userNews'])){
    if(!empty($_POST['title_news'])  && !empty($_POST['description_news']) && !empty($_POST['detail_news']))
    {
  
        $tblName='news';


 //Process the image that is uploaded by the user

        $target_dir = "../img/";
        $target_file = $target_dir . basename($_FILES["photo_news"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    
        if (move_uploaded_file($_FILES["photo_news"]["tmp_name"], $target_file)) {
            echo "The file ". basename( $_FILES["photo_news"]["name"]). " has been uploaded.";
        } else 
        {
            echo "Sorry, there was an error uploading your file.";
        }
    
        $image=basename( $_FILES["photo_news"]["name"],".jpg"); // used to store the filename in a variable
        $pt=$image.".jpg";

//

            //insert data
            $newsData = array
            (
                'Title' => str_replace ("'","@@",$_POST['title_news']),
                'Photo' => $pt,
                'Description' => str_replace ("'","@@",$_POST['description_news']),
                'Detail' => str_replace ("'","@@",$_POST['detail_news']),
                'Date'=>  date('Y/m/d')

            )
            ;
            $insert = $db->insert($tblName, $newsData);
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie avec succes.';
            //set redirect url
                $redirectURL = '../news-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard.';
                
                //set redirect url
                $redirectURL = '../news';
            }
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../news';
       }
   }


       // Code to publish the news already exists in the database
    if(isset($_REQUEST["action_type"]) && $_REQUEST["action_type"]=='post' )

    {
    
  
           $tblName='news';

   // data to be updated in the database or the table
            $Data = array
            (
                
                'Date'=>  date('Y/m/d'),
                'Status'=>'Online' 
            )
            ;

// the update condintion, means where to apply the update in a table 

             $Condition = array
            (
                
                
                'ID'=> $_REQUEST['id']
            )
            ;

            $update = $db->update($tblName, $Data,$Condition);
            if($update){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie avec succes.';
            //set redirect url
                $redirectURL = '../news-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard.';
                
                //set redirect url
                $redirectURL = '../news';
            }
    }

       // Code to delete the news already exists in the database
    if(isset($_REQUEST["action_type"]) && $_REQUEST["action_type"]=='delete' )

    {
    
  
           $tblName='news';

  

// the update condintion, means where to apply the update in a table 

             $Condition = array
            (
                
                
                'ID'=> $_REQUEST['id']
            )
            ;

            $delete = $db->delete($tblName,$Condition);
            if($delete){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Operation russie avec succes.';
            //set redirect url
                $redirectURL = '../news-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Some problem occurred, please try again.';
                
                //set redirect url
                $redirectURL = '../newslist.php';
            }
    }

   /*=================================================Spots and Videos operations , New,delete,post ===============================================================*/

if(isset($_POST['spotSubmit']))
{
    if(!empty($_POST['title'])  && !empty($_POST['link']) && !empty($_POST['description']))
    {
  
        $tblName='spot';

   //insert data
            $spotData = array
            (
                'Title' => str_replace ("'","@@",$_POST['title']),
                'Link' =>  ($_POST['link']) ,
                'Description'  => str_replace ("'","@@",$_POST['description']),
                'Date'  =>  date('Y/m/d')
            )
            ;
            $insert = $db->insert($tblName, $spotData);
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie avec succes.';
            //set redirect url
                $redirectURL = '../spot-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard.';
                
                //set redirect url
                $redirectURL = '../new-spot';
            }
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../new-spot';
       }
   }

// code to publish the spot or the video
    if(isset($_REQUEST["action_type"]) && $_REQUEST["action_type"]=='posts' )

    {
    
  
           $tblName='spot';

   // data to be updated in the database or the table
            $Data = array
            (
                
                'Date'=>  date('Y/m/d'),
                'Status'=>'Online' 
            )
            ;

// the update condintion, means where to apply the update in a table 

             $Condition = array
            (
                
                
                'ID'=> $_REQUEST['id']
            )
            ;

            $update = $db->update($tblName, $Data,$Condition);
            if($update){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie avec succes.';
            //set redirect url
                $redirectURL = '../spot-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard.';
                
                //set redirect url
                $redirectURL = '../spot-list';
            }
    }

       if(isset($_REQUEST["action_type"]) && $_REQUEST["action_type"]=='deletes' )

    {
    
  
           $tblName='spot';

  

// the update condintion, means where to apply the update in a table 

             $Condition = array
            (
                
                
                'ID'=> $_REQUEST['id']
            )
            ;

            $delete = $db->delete($tblName,$Condition);
            if($delete){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie avec succes.';
            //set redirect url
                $redirectURL = '../spot-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard.';
                
                //set redirect url
                $redirectURL = '../spot-list';
            }
    }


/*=================================================Gallery photo  operations , New,delete,post ===============================================================*/

if(isset($_POST['galNews'])){
    if(!empty($_POST['title_gal']))
    {
  
        $tblName='gallery';


 //Process the image that is uploaded by the user

        $target_dir = "../gal/";
        $target_file = $target_dir . basename($_FILES["photo_gal"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    
        if (move_uploaded_file($_FILES["photo_gal"]["tmp_name"], $target_file)) {
            echo "The file ". basename( $_FILES["photo_gal"]["name"]). " has been uploaded.";
        } else 
        {
            echo "Sorry, there was an error uploading your file.";
        }
    
        $image=basename( $_FILES["photo_gal"]["name"],".jpg"); // used to store the filename in a variable
        $pt=$image.".jpg";

//

            //insert data
            $galData = array
            (
                'Title' => str_replace ("'","@@",$_POST['title_gal']),
                'Photo' => $pt,
                'Date'=>  date('Y/m/d')

            )
            ;
            $insert = $db->insert($tblName, $galData);
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie avec succes.';
            //set redirect url
                $redirectURL = '../gal-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard.';
                
                //set redirect url
                $redirectURL = '../new-gal';
            }
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../new-gal';
       }
   }




   /*=================================================Project  operations , New,delete,post ===============================================================*/

 if(isset($_POST['projSubmit'])){
    if(!empty($_POST['title_proj']) && !empty($_POST['period_proj']) && !empty($_POST['sponsor_proj']) && !empty($_POST['location_proj']) && !empty($_POST['status_proj']) && !empty($_POST['description_proj']))
    {
  
  $tblName = 'project';
            //insert data
            $userData = array
            (
                'Title' => str_replace ("'","@@",$_POST['title_proj']),
                'Location' => str_replace ("'","@@",$_POST['location_proj']),
                'Period' => str_replace ("'","@@",$_POST['period_proj']),
                'Sponsor' => str_replace ("'","@@",$_POST['sponsor_proj']),
                'Description' => str_replace ("'","@@",$_POST['description_proj']),
                'Status' => str_replace ("'","@@",$_POST['status_proj']),
                'Date'  =>  date('Y/m/d')

            )
            ;
            $insert = $db->insert($tblName, $userData);
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie.';
            //set redirect url
                $redirectURL = '../proj-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard.';
                
                //set redirect url
                $redirectURL = '../new-proj';
            }
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../new-proj';
       }
   

}


  if(isset($_REQUEST["action_type"]) && $_REQUEST["action_type"]=='postp' )

    {
    
  
           $tblName='project';

   // data to be updated in the database or the table
            $Data = array
            (
                
                'Date'=>  date('Y/m/d'),
                'Status'=>'Terminé' 
            )
            ;

// the update condintion, means where to apply the update in a table 

             $Condition = array
            (
                
                
                'ID'=> $_REQUEST['id']
            )
            ;

            $update = $db->update($tblName, $Data,$Condition);
            if($update){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie avec succes.';
            //set redirect url
                $redirectURL = '../proj-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard.';
                
                //set redirect url
                $redirectURL = '../proj-list';
            }
    }

       if(isset($_REQUEST["action_type"]) && $_REQUEST["action_type"]=='deletep' )

    {
    
  
           $tblName='project';

  

// the update condintion, means where to apply the update in a table 

             $Condition = array
            (
                
                
                'ID'=> $_REQUEST['id']
            )
            ;

            $delete = $db->delete($tblName,$Condition);
            if($delete){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie avec succes.';
            //set redirect url
                $redirectURL = '../proj-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard.';
                
                //set redirect url
                $redirectURL = '../proj-list';
            }
    }
     /*=================================================     Login operations ===============================================================*/


 if(isset($_POST['login'])){
    if(!empty($_POST['user_email']) && !empty($_POST['pwd']))
    {
  
        



                $condition =array 
                (
                  'Email'=>$_POST['user_email'],
                  'Password'=>md5($_POST['pwd'])
                );

          $users = $db->login('user',$condition);

          if(!empty($users)): $count = 0; foreach($users as $user): $count++;


            $sessData['status']['type'] = 'success';
            $sessData['status']['msg'] = 'BIENVENUE';
            $_SESSION['name'] = $user['Firstname']."  ".$user['Lastname'];
            // $sessData['l_name']['msg'] = 'BIENVENUE';

            //set redirect url
                $redirectURL = '../control';

            endforeach; else: 

             $sessData['status']['type'] = 'error';
            $sessData['status']['msg'] = 'Connection échoueé, Essayez Plutard ';

             $redirectURL = '../login';
                    
                   endif; 

           
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../login';
       }
   

}


     if(isset($_REQUEST["action_type"]) && $_REQUEST["action_type"]=='logout' )

    {
    
  
         
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Deconnection Réussie avec succes';
            //set redirect url
                $redirectURL = '../login';

            
    }



// dream team 
    if(isset($_REQUEST["al"]) && isset($_REQUEST["us"] ) )

    {
    
  
           $tblName='forum';

  

// the update condintion, means where to apply the update in a table 
$Dte = date('Y/m/d');
            $userData = array
            (
                
                
                'alert_id'=> $_REQUEST['al'],
                'user_id'=> $_REQUEST['us'],
                'content'=> $_POST['cmt'],
                'date'=>$Dte


            )
            ;

            $insert = $db->insert($tblName, $userData);
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie.';
            //set redirect url
                $redirectURL = '../new-spot';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard.';
                
                //set redirect url
                $redirectURL = '../new-spot';
            }
    }


    /// dream team sms sending action 


    if(isset($_POST['sms'])){
    if(!empty($_POST['location'])  && !empty($_POST['detail_sms']))
    {
  
        $tblName='sms';


 //Process the image that is uploaded by the user
$msg="";
     

                            $condition =array 
                                    (
                                      //'where'=>array('condition_id' => $alert['condition_id'],),
                                      
                                      'where'=> array('condition_id' =>$_POST["weather"], )

                                    );
                            $wheather = $db->getRows('conditionn',$condition);
                    if(!empty($wheather)): $count = 0; foreach($wheather as $cond): $count++;
                                        $msg.=$cond['name']."\n".$cond['symbol'];

                                endforeach; else:
                                      endif;

$location =$_POST["location"];
       //$getInput = $_POST['select_name']; // select_name will be replaced with your input filed name
   $insert;
   $selectedOption="";
    foreach ($location as $option => $value) {
       $selectedOption .= $value.','; // I am separating Values with a comma (,) so that I can extract data using explode()

$loc="";
       $District="";
                $condition =array 
                (
                    'where'=>array('sector_id' =>$value, ),
                );

                       $sector = $db->getRows('sector',$condition);
                      if(!empty($sector)): $count = 0;  
                          foreach($sector as $sect): $count++; 

                           $loc.= $sect['name'];  


                            $condition =array 
                (
                    'where'=>array('district_id' =>$sect['district_id'] , ),
                );

                       $district = $db->getRows('district',$condition);
                      if(!empty($district)): $count = 0;  
                          foreach($district as $dist): $count++; 

                           $District.= $dist['name']."/".$loc;  
                            endforeach; else:
                      endif;
                        endforeach; else:
                      endif; 

    
        $condition =array 
                (
                  
                  'where'=>array('sector_id'=> $value )
                );
               $users = $db->getRows('user',$condition);
            if(!empty($users)): $count = 0; foreach($users as $us): $count++;
                $sm=" ALERT :"." ".$District."\n".$msg."\n".$_POST['detail_sms'];
                                          $db->sms($us['telephone'],$sm); 
                endforeach; else:
                      endif;


            $smsData = array
            (
                'sector_id'=>$value,
                'messagebody'=>$_POST['detail_sms'],
                'condition_id'=> 2,
                'source'=>'meteo',
                'date'=>  date('Y/m/d  H:i:s')

            )
            ;
            $insert = $db->insert($tblName, $smsData);
        }
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Operation done successfully .';
            //set redirect url
                $redirectURL = '../news-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Operation failed,Try again later ';
                
                //set redirect url
                $redirectURL = '../news';
            }
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../news';
       }
   }



// dream team disaster 

    if(isset($_POST['disaster'])){
    if(!empty($_POST['temperature'])  && !empty($_POST['wind_dir']) && !empty($_POST['wind_speed'])  && !empty($_POST['rain_level']) && !empty($_POST['location'])  && !empty($_POST['detail_disaster'])  && !empty($_POST['weather']) )
    {
  
        $tblName='alert';


 //Process the image that is uploaded by the user

      

$location =$_POST["location"];
       //$getInput = $_POST['select_name']; // select_name will be replaced with your input filed name
   $insert;
   $selectedOption="";
   
    foreach ($location as $option => $value) {
       //$selectedOption .= $value.','; // I am separating Values with a comma (,) so that I can extract data using explode()
   $loc="";
       $District="";
                $condition =array 
                (
                    'where'=>array('sector_id' =>$value, ),
                );

                       $sector = $db->getRows('sector',$condition);
                      if(!empty($sector)): $count = 0;  
                          foreach($sector as $sect): $count++; 

                           $loc.= $sect['name'];  


                            $condition =array 
                (
                    'where'=>array('district_id' =>$sect['district_id'] , ),
                );

                       $district = $db->getRows('district',$condition);
                      if(!empty($district)): $count = 0;  
                          foreach($district as $dist): $count++; 

                           $District.= $dist['name']."/".$loc;  
                            endforeach; else:
                      endif;
                        endforeach; else:
                      endif; 

        $condition =array 
                (
                  
                  'where'=>array('category_id'=> 8 )
                );
               $users = $db->getRows('user',$condition);
            if(!empty($users)): $count = 0; foreach($users as $us): $count++;

                $msg="ALERT  :"." ".$District."\n".$_POST['detail_disaster'];
                    $db->sms($us['telephone'],$msg); 
                endforeach; else:
                      endif;


            $smsData = array
            (
                'sector_id'=>$value,
                'max_temp'=> $_POST['temperature'],
                'rain_volume'=>$_POST['rain_level'],
                'wind_speed'=>$_POST['wind_speed'],
                'wind_direction'=>$_POST['wind_dir'],
                'content'=>$_POST['detail_disaster'],
                'condition_id'=>$_POST['weather'],
                'date'=>  date('Y/m/d  H:i:s')

            )
            ;
            $insert = $db->insert($tblName, $smsData);
        }
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Operation done successfully .';
            //set redirect url
                $redirectURL = '../user-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Operation failed,Try again later ';
                
                //set redirect url
                $redirectURL = '../register';
            }
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../news';
       }
   }



    //store status into the session
    $_SESSION['sessData'] = $sessData;
    
    //redirect to the list page
    header("Location:".$redirectURL);






exit();
?>