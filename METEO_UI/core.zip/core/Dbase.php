<?php 
/**
* 
*/
  class Dbase 
{

		private $host='localhost:3307';
		private $user='root';
		private $pwd='';
		private $dbname='aides_db';
		

		public function  Conn()

			{
					$mycon= mysqli_connect($this->host, $this->user, $this->pwd, $this->dbname);
					if (!$mycon)

						{
							die(" Not able to  connect to the server");
						}
						return $mycon;
			}
		public function GetCon()
			{
				$mycon= mysqli_connect($this->host, $this->user, $this->pwd, $this->dbname);
				return $mycon;

			}

		public function Close()
			{
				mysql_close(GetCon());
			}
			
			
			public function input($data)
				{
					$data= trim($data);
					$data= stripslashes($data);
					$data= htmlspecialchars($data);
					return $data;
				} 


	




}

?>