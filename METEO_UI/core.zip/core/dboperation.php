
<?php
// call the database connection 
include 'Dbase.php';

class dboperation

{

// function to insert in the table of a database 
public function insert($table, $fields = array())
{
	$db = new \Dbase();
    $db->Conn();
    $sql='';
		if(count($fields)){
			$keys = array_keys($fields);
			$values = null;
			$x=1;
			
			foreach($fields as $field){
				$values .= '?';
				if($x < count($fields)){
					$values .= ', ';
				}
				$x++;
			}
		 $sql = "INSERT INTO {$table} (`". implode('`, `',$keys). "`) VALUES ({$values})";
return $sql;
		
		}
		//return false;
		
	}



}


?>