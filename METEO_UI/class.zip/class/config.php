<?php
//start session
session_start();

//load and initialize database class
require_once '../core/DB.php';
$db = new DB();



//set default redirect url
$redirectURL = 'index.php';






    


 if(isset($_POST['login'])){
    if(!empty($_POST['user_email']) && !empty($_POST['pwd']))
    {
  
        



                $condition =array 
                (
                  'Email'=>$_POST['user_email'],
                  'Password'=>md5($_POST['pwd'])
                );

          $users = $db->login('user',$condition);

          if(!empty($users)): $count = 0; foreach($users as $user): $count++;


            $sessData['status']['type'] = 'success';
            $sessData['status']['msg'] = 'BIENVENUE';
            $_SESSION['name'] = $user['Firstname']."  ".$user['Lastname'];
            // $sessData['l_name']['msg'] = 'BIENVENUE';

            //set redirect url
                $redirectURL = '../control';

            endforeach; else: 

             $sessData['status']['type'] = 'error';
            $sessData['status']['msg'] = 'Connection échoueé, Essayez Plutard ';

             $redirectURL = '../login';
                    
                   endif; 

           
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../login';
       }
   

}


     if(isset($_REQUEST["action_type"]) && $_REQUEST["action_type"]=='logout' )

    {
    
  
         
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Deconnection Réussie avec succes';
            //set redirect url
                $redirectURL = '../login';

            
    }



// dream team 
    if(isset($_REQUEST["al"]) && isset($_REQUEST["us"] ) )

    {
    
  
           $tblName='forum';

  

// the update condintion, means where to apply the update in a table 
$Dte = date('Y/m/d');
            $userData = array
            (
                
                
                'alert_id'=> $_REQUEST['al'],
                'user_id'=> $_REQUEST['us'],
                'content'=> $_POST['cmt'],
                'date'=>$Dte


            )
            ;

            $insert = $db->insert($tblName, $userData);
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Opération Réussie.';
            //set redirect url
                $redirectURL = '../new-spot';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Opération échoueé, Essayez Plutard.';
                
                //set redirect url
                $redirectURL = '../new-spot';
            }
    }


    /// dream team sms sending action 


    if(isset($_POST['sms'])){
    if(!empty($_POST['location'])  && !empty($_POST['detail_sms']))
    {
  
        $tblName='sms';


 //Process the image that is uploaded by the user
$msg="";
     

                            $condition =array 
                                    (
                                      //'where'=>array('condition_id' => $alert['condition_id'],),
                                      
                                      'where'=> array('condition_id' =>$_POST["weather"], )

                                    );
                            $wheather = $db->getRows('conditionn',$condition);
                    if(!empty($wheather)): $count = 0; foreach($wheather as $cond): $count++;
                                        $msg.=$cond['name']."\n".$cond['symbol'];

                                endforeach; else:
                                      endif;

$location =$_POST["location"];
       //$getInput = $_POST['select_name']; // select_name will be replaced with your input filed name
   $insert;
   $selectedOption="";
    foreach ($location as $option => $value) {
       $selectedOption .= $value.','; // I am separating Values with a comma (,) so that I can extract data using explode()

$loc="";
       $District="";
                $condition =array 
                (
                    'where'=>array('sector_id' =>$value, ),
                );

                       $sector = $db->getRows('sector',$condition);
                      if(!empty($sector)): $count = 0;  
                          foreach($sector as $sect): $count++; 

                           $loc.= $sect['name'];  


                            $condition =array 
                (
                    'where'=>array('district_id' =>$sect['district_id'] , ),
                );

                       $district = $db->getRows('district',$condition);
                      if(!empty($district)): $count = 0;  
                          foreach($district as $dist): $count++; 

                           $District.= $dist['name']."/".$loc;  
                            endforeach; else:
                      endif;
                        endforeach; else:
                      endif; 

    
        $condition =array 
                (
                  
                  'where'=>array('sector_id'=> $value )
                );
               $users = $db->getRows('user',$condition);
            if(!empty($users)): $count = 0; foreach($users as $us): $count++;
                $sm=" ALERT :"." ".$District."\n".$msg."\n".$_POST['detail_sms'];
                                          $db->sms($us['telephone'],$sm); 
                endforeach; else:
                      endif;


            $smsData = array
            (
                'sector_id'=>$value,
                'messagebody'=>$_POST['detail_sms'],
                'condition_id'=> 2,
                'source'=>'meteo',
                'date'=>  date('Y/m/d  H:i:s')

            )
            ;
            $insert = $db->insert($tblName, $smsData);
        }
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Operation done successfully .';
            //set redirect url
                $redirectURL = '../news-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Operation failed,Try again later ';
                
                //set redirect url
                $redirectURL = '../news';
            }
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../news';
       }
   }



// dream team disaster 

    if(isset($_POST['disaster'])){
    if(!empty($_POST['temperature'])  && !empty($_POST['wind_dir']) && !empty($_POST['wind_speed'])  && !empty($_POST['rain_level']) && !empty($_POST['location'])  && !empty($_POST['detail_disaster'])  && !empty($_POST['weather']) )
    {
  
        $tblName='alert';


 //Process the image that is uploaded by the user

      

$location =$_POST["location"];
       //$getInput = $_POST['select_name']; // select_name will be replaced with your input filed name
   $insert;
   $selectedOption="";
   
    foreach ($location as $option => $value) {
       //$selectedOption .= $value.','; // I am separating Values with a comma (,) so that I can extract data using explode()
   $loc="";
       $District="";
                $condition =array 
                (
                    'where'=>array('sector_id' =>$value, ),
                );

                       $sector = $db->getRows('sector',$condition);
                      if(!empty($sector)): $count = 0;  
                          foreach($sector as $sect): $count++; 

                           $loc.= $sect['name'];  


                            $condition =array 
                (
                    'where'=>array('district_id' =>$sect['district_id'] , ),
                );

                       $district = $db->getRows('district',$condition);
                      if(!empty($district)): $count = 0;  
                          foreach($district as $dist): $count++; 

                           $District.= $dist['name']."/".$loc;  
                            endforeach; else:
                      endif;
                        endforeach; else:
                      endif; 

        $condition =array 
                (
                  
                  'where'=>array('category_id'=> 8 )
                );
               $users = $db->getRows('user',$condition);
            if(!empty($users)): $count = 0; foreach($users as $us): $count++;

                $msg="ALERT  :"." ".$District."\n".$_POST['detail_disaster'];
                    $db->sms($us['telephone'],$msg); 
                endforeach; else:
                      endif;


            $smsData = array
            (
                'sector_id'=>$value,
                'max_temp'=> $_POST['temperature'],
                'rain_volume'=>$_POST['rain_level'],
                'wind_speed'=>$_POST['wind_speed'],
                'wind_direction'=>$_POST['wind_dir'],
                'content'=>$_POST['detail_disaster'],
                'condition_id'=>$_POST['weather'],
                'date'=>  date('Y/m/d  H:i:s')

            )
            ;
            $insert = $db->insert($tblName, $smsData);
        }
            if($insert){
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'Operation done successfully .';
            //set redirect url
                $redirectURL = '../user-list';

            }
            else{
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Operation failed,Try again later ';
                
                //set redirect url
                $redirectURL = '../register';
            }
    }

    else 
    {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'All fields are mandatory, please fill all the fields.';
        
        //set redirect url
        $redirectURL = '../news';
       }
   }



    //store status into the session
    $_SESSION['sessData'] = $sessData;
    
    //redirect to the list page
    header("Location:".$redirectURL);






exit();
?>